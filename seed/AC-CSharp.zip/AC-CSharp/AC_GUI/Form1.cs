﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using ACLib;

namespace AC_GUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void browseSourceButton_Click(object sender, EventArgs e)
        {
            sourceOpenFileDialog.ShowDialog();
        }

        private void sourceOpenFileDialog_FileOk(object sender, CancelEventArgs e)
        {
            sourceText.Text = sourceOpenFileDialog.FileName;
        }

        private void browseTargetButton_Click(object sender, EventArgs e)
        {
            targetOpenFileDialog.ShowDialog();
        }

        private void targetOpenFileDialog_FileOk(object sender, CancelEventArgs e)
        {
            targetText.Text = targetOpenFileDialog.FileName;
        }

        private void encodeButton_Click(object sender, EventArgs e)
        {
            AbstractModel model = new ModelOrder0();
            
            FileInfo sourceFile, targetFile;
            FileStream sourceStream, targetStream;

            try
            {
                sourceFile = new FileInfo(sourceText.Text);
                sourceStream = sourceFile.OpenRead();
            }
            catch (Exception openSourceException)
            {
                MessageBox.Show("Error1! Cannot open source file for read");
                return;
            }

            try
            {
                targetFile = new FileInfo(targetText.Text);
                targetStream = targetFile.OpenWrite();
            }
            catch (Exception openTargetException)
            {
                MessageBox.Show("Error2! Cannot open target file to write!");
                return;
            }

            // Information
            sourceFileSizeValueText.Text = sourceFile.Length.ToString();

            sourceStream.Seek(0, SeekOrigin.Begin);
            byte[] writtenBytes = Encoding.Default.GetBytes(Program.g_Signature);
            targetStream.Write(writtenBytes, 0, 4);

            DateTime firstTime = DateTime.Now;
            
            // Main compression function
            model.Process(sourceStream, targetStream, ModeE.MODE_ENCODE);

            DateTime secondTime = DateTime.Now;
            TimeSpan duration = secondTime - firstTime;

            sourceStream.Close();
            targetStream.Close();

            // Information
            targetFileSizeValueText.Text = targetFile.Length.ToString();
            compressionRatioValueText.Text = ((double)sourceFile.Length / (double)targetFile.Length).ToString();
            timeValueText.Text = duration.TotalMilliseconds.ToString();

            MessageBox.Show("Encoding Succeeded!");
        }

        private void decodeButton_Click(object sender, EventArgs e)
        {
            AbstractModel model = new ModelOrder0();

            FileInfo sourceFile, targetFile;
            FileStream sourceStream, targetStream;

            try
            {
                sourceFile = new FileInfo(sourceText.Text);
                sourceStream = sourceFile.OpenRead();
            }
            catch (Exception openSourceException)
            {
                MessageBox.Show("Error1! Cannot open source file for read");
                return;
            }

            try
            {
                targetFile = new FileInfo(targetText.Text);
                targetStream = targetFile.OpenWrite();
            }
            catch (Exception openTargetException)
            {
                MessageBox.Show("Error2! Cannot open target file to write!");
                return;
            }

            // Information
            sourceFileSizeValueText.Text = sourceFile.Length.ToString();

            byte[] readBytes = new byte[4];
            sourceStream.Read(readBytes, 0, 4);
            string signature = Encoding.Default.GetString(readBytes);

            if (signature != Program.g_Signature)
            {
                MessageBox.Show("Error3! Not valid encoded AC file as Source!");
                return;
            }

            DateTime firstTime = DateTime.Now;

            // Main compression function
            model.Process(sourceStream, targetStream, ModeE.MODE_DECODE);

            DateTime secondTime = DateTime.Now;
            TimeSpan duration = secondTime - firstTime;

            sourceStream.Close();
            targetStream.Close();

            // Information
            targetFileSizeValueText.Text = targetFile.Length.ToString();
            compressionRatioValueText.Text = ((double)targetFile.Length / (double)sourceFile.Length).ToString();
            timeValueText.Text = duration.TotalMilliseconds.ToString();

            MessageBox.Show("Decoding Succeeded!");
        }

    }
}
