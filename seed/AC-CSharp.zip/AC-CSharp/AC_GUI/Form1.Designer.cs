﻿namespace AC_GUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.sourceOpenFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.sourceLabel = new System.Windows.Forms.Label();
            this.targetLabel = new System.Windows.Forms.Label();
            this.sourceText = new System.Windows.Forms.TextBox();
            this.targetText = new System.Windows.Forms.TextBox();
            this.browseSourceButton = new System.Windows.Forms.Button();
            this.browseTargetButton = new System.Windows.Forms.Button();
            this.targetOpenFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.encodeButton = new System.Windows.Forms.Button();
            this.decodeButton = new System.Windows.Forms.Button();
            this.sourceFileSizeLabel = new System.Windows.Forms.Label();
            this.targetFileSizeLabel = new System.Windows.Forms.Label();
            this.infoGroupBox = new System.Windows.Forms.GroupBox();
            this.timeValueText = new System.Windows.Forms.TextBox();
            this.compressionRatioValueText = new System.Windows.Forms.TextBox();
            this.targetFileSizeValueText = new System.Windows.Forms.TextBox();
            this.sourceFileSizeValueText = new System.Windows.Forms.TextBox();
            this.timeLabel = new System.Windows.Forms.Label();
            this.compressionRatioLabel = new System.Windows.Forms.Label();
            this.ericBoddenLabel = new System.Windows.Forms.Label();
            this.referenceLinkLabel = new System.Windows.Forms.LinkLabel();
            this.authorLabel = new System.Windows.Forms.Label();
            this.emailLinkLabel = new System.Windows.Forms.LinkLabel();
            this.infoGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // sourceOpenFileDialog
            // 
            this.sourceOpenFileDialog.FileName = "openFileDialog1";
            this.sourceOpenFileDialog.SupportMultiDottedExtensions = true;
            this.sourceOpenFileDialog.Title = "Browse the Source File";
            this.sourceOpenFileDialog.FileOk += new System.ComponentModel.CancelEventHandler(this.sourceOpenFileDialog_FileOk);
            // 
            // sourceLabel
            // 
            this.sourceLabel.AutoSize = true;
            this.sourceLabel.Location = new System.Drawing.Point(15, 118);
            this.sourceLabel.Name = "sourceLabel";
            this.sourceLabel.Size = new System.Drawing.Size(79, 17);
            this.sourceLabel.TabIndex = 0;
            this.sourceLabel.Text = "SourceFile:";
            // 
            // targetLabel
            // 
            this.targetLabel.AutoSize = true;
            this.targetLabel.Location = new System.Drawing.Point(15, 153);
            this.targetLabel.Name = "targetLabel";
            this.targetLabel.Size = new System.Drawing.Size(76, 17);
            this.targetLabel.TabIndex = 1;
            this.targetLabel.Text = "TargetFile:";
            // 
            // sourceText
            // 
            this.sourceText.Location = new System.Drawing.Point(100, 115);
            this.sourceText.Name = "sourceText";
            this.sourceText.Size = new System.Drawing.Size(477, 22);
            this.sourceText.TabIndex = 2;
            // 
            // targetText
            // 
            this.targetText.Location = new System.Drawing.Point(100, 150);
            this.targetText.Name = "targetText";
            this.targetText.Size = new System.Drawing.Size(477, 22);
            this.targetText.TabIndex = 3;
            // 
            // browseSourceButton
            // 
            this.browseSourceButton.Location = new System.Drawing.Point(583, 113);
            this.browseSourceButton.Name = "browseSourceButton";
            this.browseSourceButton.Size = new System.Drawing.Size(145, 27);
            this.browseSourceButton.TabIndex = 4;
            this.browseSourceButton.Text = "Browse Source";
            this.browseSourceButton.UseVisualStyleBackColor = true;
            this.browseSourceButton.Click += new System.EventHandler(this.browseSourceButton_Click);
            // 
            // browseTargetButton
            // 
            this.browseTargetButton.Location = new System.Drawing.Point(583, 148);
            this.browseTargetButton.Name = "browseTargetButton";
            this.browseTargetButton.Size = new System.Drawing.Size(145, 26);
            this.browseTargetButton.TabIndex = 5;
            this.browseTargetButton.Text = "Browse Target";
            this.browseTargetButton.UseVisualStyleBackColor = true;
            this.browseTargetButton.Click += new System.EventHandler(this.browseTargetButton_Click);
            // 
            // targetOpenFileDialog
            // 
            this.targetOpenFileDialog.CheckFileExists = false;
            this.targetOpenFileDialog.CheckPathExists = false;
            this.targetOpenFileDialog.DefaultExt = "ac";
            this.targetOpenFileDialog.FileName = "openFileDialog1";
            this.targetOpenFileDialog.SupportMultiDottedExtensions = true;
            this.targetOpenFileDialog.Title = "Select Destination File";
            this.targetOpenFileDialog.FileOk += new System.ComponentModel.CancelEventHandler(this.targetOpenFileDialog_FileOk);
            // 
            // encodeButton
            // 
            this.encodeButton.Location = new System.Drawing.Point(583, 187);
            this.encodeButton.Name = "encodeButton";
            this.encodeButton.Size = new System.Drawing.Size(66, 42);
            this.encodeButton.TabIndex = 6;
            this.encodeButton.Text = "Encode";
            this.encodeButton.UseVisualStyleBackColor = true;
            this.encodeButton.Click += new System.EventHandler(this.encodeButton_Click);
            // 
            // decodeButton
            // 
            this.decodeButton.Location = new System.Drawing.Point(662, 187);
            this.decodeButton.Name = "decodeButton";
            this.decodeButton.Size = new System.Drawing.Size(66, 42);
            this.decodeButton.TabIndex = 7;
            this.decodeButton.Text = "Decode";
            this.decodeButton.UseVisualStyleBackColor = true;
            this.decodeButton.Click += new System.EventHandler(this.decodeButton_Click);
            // 
            // sourceFileSizeLabel
            // 
            this.sourceFileSizeLabel.AutoSize = true;
            this.sourceFileSizeLabel.Location = new System.Drawing.Point(15, 27);
            this.sourceFileSizeLabel.Name = "sourceFileSizeLabel";
            this.sourceFileSizeLabel.Size = new System.Drawing.Size(163, 17);
            this.sourceFileSizeLabel.TabIndex = 8;
            this.sourceFileSizeLabel.Text = "Source File Size (Bytes):";
            // 
            // targetFileSizeLabel
            // 
            this.targetFileSizeLabel.AutoSize = true;
            this.targetFileSizeLabel.Location = new System.Drawing.Point(18, 56);
            this.targetFileSizeLabel.Name = "targetFileSizeLabel";
            this.targetFileSizeLabel.Size = new System.Drawing.Size(160, 17);
            this.targetFileSizeLabel.TabIndex = 9;
            this.targetFileSizeLabel.Text = "Target File Size (Bytes):";
            // 
            // infoGroupBox
            // 
            this.infoGroupBox.Controls.Add(this.timeValueText);
            this.infoGroupBox.Controls.Add(this.compressionRatioValueText);
            this.infoGroupBox.Controls.Add(this.targetFileSizeValueText);
            this.infoGroupBox.Controls.Add(this.sourceFileSizeValueText);
            this.infoGroupBox.Controls.Add(this.timeLabel);
            this.infoGroupBox.Controls.Add(this.compressionRatioLabel);
            this.infoGroupBox.Controls.Add(this.sourceFileSizeLabel);
            this.infoGroupBox.Controls.Add(this.targetFileSizeLabel);
            this.infoGroupBox.Location = new System.Drawing.Point(18, 12);
            this.infoGroupBox.Name = "infoGroupBox";
            this.infoGroupBox.Size = new System.Drawing.Size(710, 95);
            this.infoGroupBox.TabIndex = 10;
            this.infoGroupBox.TabStop = false;
            this.infoGroupBox.Text = "Information";
            // 
            // timeValueText
            // 
            this.timeValueText.Location = new System.Drawing.Point(518, 56);
            this.timeValueText.Name = "timeValueText";
            this.timeValueText.ReadOnly = true;
            this.timeValueText.Size = new System.Drawing.Size(177, 22);
            this.timeValueText.TabIndex = 18;
            // 
            // compressionRatioValueText
            // 
            this.compressionRatioValueText.Location = new System.Drawing.Point(518, 27);
            this.compressionRatioValueText.Name = "compressionRatioValueText";
            this.compressionRatioValueText.ReadOnly = true;
            this.compressionRatioValueText.Size = new System.Drawing.Size(177, 22);
            this.compressionRatioValueText.TabIndex = 17;
            // 
            // targetFileSizeValueText
            // 
            this.targetFileSizeValueText.Location = new System.Drawing.Point(184, 56);
            this.targetFileSizeValueText.Name = "targetFileSizeValueText";
            this.targetFileSizeValueText.ReadOnly = true;
            this.targetFileSizeValueText.Size = new System.Drawing.Size(177, 22);
            this.targetFileSizeValueText.TabIndex = 16;
            // 
            // sourceFileSizeValueText
            // 
            this.sourceFileSizeValueText.Location = new System.Drawing.Point(184, 27);
            this.sourceFileSizeValueText.Name = "sourceFileSizeValueText";
            this.sourceFileSizeValueText.ReadOnly = true;
            this.sourceFileSizeValueText.Size = new System.Drawing.Size(177, 22);
            this.sourceFileSizeValueText.TabIndex = 11;
            // 
            // timeLabel
            // 
            this.timeLabel.AutoSize = true;
            this.timeLabel.Location = new System.Drawing.Point(437, 56);
            this.timeLabel.Name = "timeLabel";
            this.timeLabel.Size = new System.Drawing.Size(75, 17);
            this.timeLabel.TabIndex = 13;
            this.timeLabel.Text = "Time (ms):";
            // 
            // compressionRatioLabel
            // 
            this.compressionRatioLabel.AutoSize = true;
            this.compressionRatioLabel.Location = new System.Drawing.Point(381, 27);
            this.compressionRatioLabel.Name = "compressionRatioLabel";
            this.compressionRatioLabel.Size = new System.Drawing.Size(131, 17);
            this.compressionRatioLabel.TabIndex = 12;
            this.compressionRatioLabel.Text = "Compression Ratio:";
            // 
            // ericBoddenLabel
            // 
            this.ericBoddenLabel.AutoSize = true;
            this.ericBoddenLabel.Location = new System.Drawing.Point(26, 245);
            this.ericBoddenLabel.Name = "ericBoddenLabel";
            this.ericBoddenLabel.Size = new System.Drawing.Size(687, 17);
            this.ericBoddenLabel.TabIndex = 11;
            this.ericBoddenLabel.Text = "This program is reimplemented from the main idea and source code of Eric Bodden a" +
                "nd some other articles.";
            // 
            // referenceLinkLabel
            // 
            this.referenceLinkLabel.AutoSize = true;
            this.referenceLinkLabel.Location = new System.Drawing.Point(226, 274);
            this.referenceLinkLabel.Name = "referenceLinkLabel";
            this.referenceLinkLabel.Size = new System.Drawing.Size(304, 17);
            this.referenceLinkLabel.TabIndex = 12;
            this.referenceLinkLabel.TabStop = true;
            this.referenceLinkLabel.Text = "http://www.bodden.de/legacy/arithmetic-coding/";
            // 
            // authorLabel
            // 
            this.authorLabel.AutoSize = true;
            this.authorLabel.Location = new System.Drawing.Point(270, 305);
            this.authorLabel.Name = "authorLabel";
            this.authorLabel.Size = new System.Drawing.Size(218, 17);
            this.authorLabel.TabIndex = 13;
            this.authorLabel.Text = "Reimplemented by: Sina Momken";
            // 
            // emailLinkLabel
            // 
            this.emailLinkLabel.AutoSize = true;
            this.emailLinkLabel.Location = new System.Drawing.Point(293, 333);
            this.emailLinkLabel.Name = "emailLinkLabel";
            this.emailLinkLabel.Size = new System.Drawing.Size(168, 17);
            this.emailLinkLabel.TabIndex = 14;
            this.emailLinkLabel.TabStop = true;
            this.emailLinkLabel.Text = "sina.momken@gmail.com";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(740, 364);
            this.Controls.Add(this.emailLinkLabel);
            this.Controls.Add(this.authorLabel);
            this.Controls.Add(this.referenceLinkLabel);
            this.Controls.Add(this.ericBoddenLabel);
            this.Controls.Add(this.infoGroupBox);
            this.Controls.Add(this.decodeButton);
            this.Controls.Add(this.encodeButton);
            this.Controls.Add(this.browseTargetButton);
            this.Controls.Add(this.browseSourceButton);
            this.Controls.Add(this.targetText);
            this.Controls.Add(this.sourceText);
            this.Controls.Add(this.targetLabel);
            this.Controls.Add(this.sourceLabel);
            this.Name = "Form1";
            this.Text = "Arithmetic Coder";
            this.infoGroupBox.ResumeLayout(false);
            this.infoGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog sourceOpenFileDialog;
        private System.Windows.Forms.Label sourceLabel;
        private System.Windows.Forms.Label targetLabel;
        private System.Windows.Forms.TextBox sourceText;
        private System.Windows.Forms.TextBox targetText;
        private System.Windows.Forms.Button browseSourceButton;
        private System.Windows.Forms.Button browseTargetButton;
        private System.Windows.Forms.OpenFileDialog targetOpenFileDialog;
        private System.Windows.Forms.Button encodeButton;
        private System.Windows.Forms.Button decodeButton;
        private System.Windows.Forms.Label sourceFileSizeLabel;
        private System.Windows.Forms.Label targetFileSizeLabel;
        private System.Windows.Forms.GroupBox infoGroupBox;
        private System.Windows.Forms.Label timeLabel;
        private System.Windows.Forms.Label compressionRatioLabel;
        private System.Windows.Forms.TextBox sourceFileSizeValueText;
        private System.Windows.Forms.TextBox timeValueText;
        private System.Windows.Forms.TextBox compressionRatioValueText;
        private System.Windows.Forms.TextBox targetFileSizeValueText;
        private System.Windows.Forms.Label ericBoddenLabel;
        private System.Windows.Forms.LinkLabel referenceLinkLabel;
        private System.Windows.Forms.Label authorLabel;
        private System.Windows.Forms.LinkLabel emailLinkLabel;
    }
}

